package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Menu module 7 tab.
 * Chuột trái vào module = bật/tắt • Chuột phải = mở/đóng bảng cài đặt (Mode, Slider, Checkbox, Keybind, Color).
 * Kéo (hoặc lăn chuột) để cuộn danh sách.
 */
public class ModulesScreen extends Screen {
    static final int MOD = 0, MODE = 1, SLIDER = 2, CHECK = 3, KEY = 4, COLOR = 5, GRID = 6, ALPHA = 7, RAINBOW = 8;
    static final int ACC = 0xFF8B5CF6;
    static int tab = 0;

    static class Row { int kind, y, h; Module m; Setting s; }

    final Screen parent;
    final List<Row> rows = new ArrayList<>();
    double scroll, content;
    Row dragRow; boolean scrolling; double downX, downY; int downBtn = -1; Row downRow;

    public ModulesScreen(Screen parent) { super(Text.literal("Modules")); this.parent = parent; }

    int pw() { return Math.min(width - 12, 360); }
    int px() { return (width - pw()) / 2; }
    int listTop() { return 56; }
    int listBottom() { return height - 18; }
    Module.Cat cat() { return Module.Cat.values()[tab]; }

    @Override protected void init() { build(); }
    @Override public void close() { MinecraftClient.getInstance().setScreen(parent); }
    @Override public void removed() { for (Module m : ModuleManager.ALL) m.bind.listening = false; ModuleManager.save(); Config.save(); }
    @Override public boolean shouldPause() { return false; }

    // ---------------- bố cục ----------------
    void build() {
        rows.clear(); int y = 0;
        for (Module m : ModuleManager.of(cat())) {
            y = add(MOD, m, null, y, 22);
            if (!m.expanded) continue;
            y = add(KEY, m, m.bind, y, 18);
            for (Setting s : m.settings) {
                if (s instanceof Setting.Mode) y = add(MODE, m, s, y, 18);
                else if (s instanceof Setting.Slider) y = add(SLIDER, m, s, y, 18);
                else if (s instanceof Setting.Check) y = add(CHECK, m, s, y, 18);
                else if (s instanceof Setting.Key) y = add(KEY, m, s, y, 18);
                else if (s instanceof Setting.Color c) {
                    y = add(COLOR, m, s, y, 18);
                    if (c.open) { y = add(GRID, m, s, y, 52); y = add(ALPHA, m, s, y, 18); y = add(RAINBOW, m, s, y, 18); }
                }
            }
            y += 4;
        }
        content = y;
        clamp();
    }
    int add(int kind, Module m, Setting s, int y, int h) { Row r = new Row(); r.kind = kind; r.m = m; r.s = s; r.y = y; r.h = h; rows.add(r); return y + h + 2; }
    void clamp() { scroll = Math.max(0, Math.min(Math.max(0, content - (listBottom() - listTop())), scroll)); }
    int sy(Row r) { return (int) (listTop() + r.y - scroll); }
    Row rowAt(double mx, double my) {
        if (my < listTop() || my > listBottom() || mx < px() || mx > px() + pw()) return null;
        for (Row r : rows) { int y = sy(r); if (my >= y && my < y + r.h) return r; }
        return null;
    }
    int tabAt(double mx, double my) {
        if (my < 30 || my > 50 || mx < px() || mx > px() + pw()) return -1;
        int n = Module.Cat.values().length; return Math.min(n - 1, (int) ((mx - px()) * n / pw()));
    }

    // ---------------- vẽ ----------------
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float d) {
        ctx.fill(0, 0, width, height, 0xC00B0B14);
        ctx.fill(px() - 4, 0, px() + pw() + 4, height, 0xF0161624);
        ctx.fill(px() - 4, 0, px() - 3, height, ACC); ctx.fill(px() + pw() + 3, 0, px() + pw() + 4, height, ACC);
    }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        renderBackground(ctx, mx, my, d);
        var tr = textRenderer; int X = px(), W = pw();
        Anim.title(ctx, width / 2, 8);
        // tab bar
        Module.Cat[] cats = Module.Cat.values(); int n = cats.length;
        for (int i = 0; i < n; i++) {
            int x0 = X + W * i / n, x1 = X + W * (i + 1) / n; boolean sel = i == tab, hov = tabAt(mx, my) == i;
            ctx.fill(x0, 30, x1 - 1, 50, sel ? ACC : hov ? 0xFF2E2E48 : 0xFF1F1F32);
            String lb = cats[i].label; if (tr.getWidth(lb) > x1 - x0 - 2) lb = lb.substring(0, 3);
            ctx.drawCenteredTextWithShadow(tr, lb, (x0 + x1) / 2, 36, sel ? 0xFFFFFFFF : 0xFFB0B0C8);
        }
        // danh sách
        ctx.enableScissor(0, listTop(), width, listBottom());
        Row hover = rowAt(mx, my);
        for (Row r : rows) {
            int y = sy(r); if (y + r.h < listTop() || y > listBottom()) continue;
            boolean hv = r == hover; Module m = r.m;
            switch (r.kind) {
                case MOD -> {
                    boolean on = m.isOn();
                    ctx.fill(X, y, X + W, y + r.h, on ? (hv ? 0xFF6D3FD6 : 0xFF5B34B4) : (hv ? 0xFF2A2A40 : 0xFF202034));
                    ctx.fill(X, y, X + 3, y + r.h, on ? 0xFFFF69B4 : 0xFF3A3A55);
                    String nm = m.name + (m.implemented ? "" : " §8(chưa có logic)");
                    ctx.drawTextWithShadow(tr, nm, X + 9, y + 7, on ? 0xFFFFFFFF : 0xFFBBBBCC);
                    String st = (on ? "§aON" : "§7OFF") + "  §8" + (m.expanded ? "▾" : "▸");
                    ctx.drawTextWithShadow(tr, st, X + W - tr.getWidth(st.replaceAll("§.", "")) - 6, y + 7, 0xFFFFFFFF);
                }
                case MODE -> { Setting.Mode s = (Setting.Mode) r.s; bar(ctx, X, y, W, hv); ctx.drawTextWithShadow(tr, s.name + ": §e" + s.get() + "  §8◀ ▶ (trái/phải)", X + 14, y + 5, 0xFFFFFFFF); }
                case SLIDER -> { Setting.Slider s = (Setting.Slider) r.s; bar(ctx, X, y, W, hv);
                    int bw = (int) ((W - 16) * s.frac()); ctx.fill(X + 8, y + 1, X + 8 + bw, y + r.h - 1, 0xFF6D3FD6);
                    ctx.drawCenteredTextWithShadow(tr, s.name + ": " + s.text(), X + W / 2, y + 5, 0xFFFFFFFF); }
                case CHECK, RAINBOW -> { boolean v; String nm;
                    if (r.kind == CHECK) { Setting.Check s = (Setting.Check) r.s; v = s.get(); nm = s.name; } else { v = ((Setting.Color) r.s).rainbow; nm = "Rainbow"; }
                    bar(ctx, X, y, W, hv); box(ctx, X + 14, y + 4, v); ctx.drawTextWithShadow(tr, nm, X + 30, y + 5, 0xFFFFFFFF); }
                case KEY -> { Setting.Key s = (Setting.Key) r.s; bar(ctx, X, y, W, hv); ctx.drawTextWithShadow(tr, "Keybind: §e" + s.label(), X + 14, y + 5, 0xFFFFFFFF); }
                case COLOR -> { Setting.Color s = (Setting.Color) r.s; bar(ctx, X, y, W, hv);
                    ctx.drawTextWithShadow(tr, "Màu: " + s.name + (s.open ? " §8▾" : " §8▸"), X + 14, y + 5, 0xFFFFFFFF);
                    ctx.fill(X + W - 38, y + 3, X + W - 10, y + 15, 0xFFFFFFFF); ctx.fill(X + W - 37, y + 4, X + W - 11, y + 14, 0xFF000000 | (s.argb() & 0xFFFFFF)); }
                case GRID -> { Setting.Color s = (Setting.Color) r.s; int gx = X + 8, gw = W - 16, gh = r.h, b = 4;
                    ctx.fill(gx - 1, y - 1, gx + gw + 1, y + gh + 1, 0xFF000000);
                    for (int cx = 0; cx < gw; cx += b) for (int cy = 0; cy < gh; cy += b)
                        ctx.fill(gx + cx, y + cy, Math.min(gx + cx + b, gx + gw), Math.min(y + cy + b, y + gh), 0xFF000000 | (ColorScreen.shade((cx + b / 2.0) / gw, (cy + b / 2.0) / gh) & 0xFFFFFF)); }
                case ALPHA -> { Setting.Color s = (Setting.Color) r.s; bar(ctx, X, y, W, hv);
                    ctx.fill(X + 8, y + 1, X + 8 + (int) ((W - 16) * s.alpha / 255.0), y + r.h - 1, 0xFF6D3FD6);
                    ctx.drawCenteredTextWithShadow(tr, "Alpha: " + s.alpha, X + W / 2, y + 5, 0xFFFFFFFF); }
                default -> {}
            }
        }
        ctx.disableScissor();
        // thanh mô tả
        String hint = hover != null ? hover.m.desc : "";
        if (hover != null && hover.kind == MOD) hint += "   §8• chuột trái: bật/tắt • chuột phải: cài đặt";
        ctx.drawTextWithShadow(tr, hint, X, height - 12, 0xFFAAAAAA);
    }
    void bar(DrawContext ctx, int X, int y, int W, boolean hv) { ctx.fill(X + 6, y, X + W - 6, y + 18, hv ? 0xFF26263C : 0xFF1A1A2B); }
    void box(DrawContext ctx, int x, int y, boolean on) { ctx.fill(x, y, x + 10, y + 10, 0xFFB0B0C8); ctx.fill(x + 1, y + 1, x + 9, y + 9, on ? 0xFFFF69B4 : 0xFF14141F); }

    // ---------------- chuột ----------------
    void sliderTo(Row r, double mx) { double f = (mx - (px() + 8)) / (pw() - 16);
        if (r.kind == SLIDER) ((Setting.Slider) r.s).setFrac(f);
        else if (r.kind == ALPHA) ((Setting.Color) r.s).alpha = (int) Math.round(Math.max(0, Math.min(1, f)) * 255); }
    void gridTo(Row r, double mx, double my) { Setting.Color c = (Setting.Color) r.s;
        double hx = Math.max(0, Math.min(1, (mx - (px() + 8)) / (pw() - 16))), sy = Math.max(0, Math.min(1, (my - sy(r)) / (double) r.h));
        c.rgb = ColorScreen.shade(hx, sy) & 0xFFFFFF; c.rainbow = false; }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        for (Module m : ModuleManager.ALL) if (m.bind.listening) { m.bind.listening = false; return true; }   // bấm chuột = hủy gán phím
        int t = tabAt(mx, my);
        if (t >= 0) { tab = t; scroll = 0; build(); return true; }
        Row r = rowAt(mx, my); downX = mx; downY = my; downBtn = btn; downRow = r; scrolling = false; dragRow = null;
        if (r != null && btn == 0) {
            if (r.kind == SLIDER || r.kind == ALPHA) { dragRow = r; sliderTo(r, mx); return true; }
            if (r.kind == GRID) { dragRow = r; gridTo(r, mx, my); return true; }
        }
        return true;
    }

    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragRow != null) { if (dragRow.kind == GRID) gridTo(dragRow, mx, my); else sliderTo(dragRow, mx); return true; }
        if (Math.abs(my - downY) > 5) scrolling = true;
        if (scrolling) { scroll -= dy; clamp(); }
        return true;
    }

    @Override public boolean mouseReleased(double mx, double my, int btn) {
        if (dragRow != null) { dragRow = null; ModuleManager.save(); return true; }
        if (!scrolling && downRow != null && btn == downBtn) click(downRow, btn);
        downRow = null; scrolling = false; return true;
    }

    void click(Row r, int btn) {
        Module m = r.m;
        switch (r.kind) {
            case MOD -> {
                if (btn == 1) { boolean open = !m.expanded; for (Module o : ModuleManager.ALL) o.expanded = false; m.expanded = open; build(); }   // chuột phải: mở/đóng cài đặt
                else if (btn == 0) { m.toggle(); Util.msg(m.name + ": " + (m.isOn() ? "§aBẬT" : "§cTẮT")); }
            }
            case MODE -> { Setting.Mode s = (Setting.Mode) r.s; if (btn == 1) s.prev(); else s.next(); ModuleManager.save(); }
            case CHECK -> { Setting.Check s = (Setting.Check) r.s; s.value = !s.value; ModuleManager.save(); }
            case RAINBOW -> { Setting.Color s = (Setting.Color) r.s; s.rainbow = !s.rainbow; ModuleManager.save(); }
            case KEY -> { Setting.Key s = (Setting.Key) r.s; s.listening = true; }
            case COLOR -> { Setting.Color s = (Setting.Color) r.s; s.open = !s.open; build(); }
            default -> {}
        }
    }

    @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll -= v * 24; clamp(); return true; }

    @Override public boolean keyPressed(int key, int scan, int mods) {
        for (Module m : ModuleManager.ALL) if (m.bind.listening) {
            m.bind.listening = false;
            if (key == 259 || key == 261) m.bind.key = -1; else if (key != 256) m.bind.key = key;
            ModuleManager.save(); return true;
        }
        if (key == 256) { close(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
