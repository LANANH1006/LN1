package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/** Dự đoán đường bay của pearl / đồ ném / mũi tên (khi đang kéo cung). */
public class Traj {
    public static class Result {
        public final List<Vec3d> pts = new ArrayList<>();
        public BlockPos land;
        public PlayerEntity hit;
    }

    public static Result compute(MinecraftClient mc, float td) {
        var p = mc.player; var w = mc.world;
        ItemStack st = p.getMainHandStack();
        double speed, grav, roll = 0;
        if (st.isOf(Items.ENDER_PEARL) || st.isOf(Items.SNOWBALL) || st.isOf(Items.EGG)) { speed = 1.5; grav = 0.03; }
        else if (st.isOf(Items.SPLASH_POTION) || st.isOf(Items.LINGERING_POTION)) { speed = 0.5; grav = 0.05; roll = -20; }
        else if (st.isOf(Items.EXPERIENCE_BOTTLE)) { speed = 0.7; grav = 0.07; roll = -20; }
        else if (st.isOf(Items.BOW) && p.isUsingItem() && p.getActiveItem().isOf(Items.BOW)) {
            float f = p.getItemUseTime() / 20f; f = (f * f + f * 2f) / 3f; if (f > 1f) f = 1f;
            if (f < 0.1f) return null;
            speed = f * 3.0; grav = 0.05;
        } else return null;

        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch()), rr = Math.toRadians(p.getPitch() + roll);
        Vec3d dir = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(rr), Math.cos(yr) * Math.cos(pr)).normalize().multiply(speed);
        Vec3d vel = dir.add(p.getVelocity().x, p.isOnGround() ? 0 : p.getVelocity().y, p.getVelocity().z);
        Vec3d pos = p.getCameraPosVec(td).add(0, -0.1, 0);

        Result r = new Result();
        r.pts.add(pos);
        for (int i = 0; i < 160; i++) {
            Vec3d next = pos.add(vel);
            for (PlayerEntity o : w.getPlayers()) {
                if (o == p || o.isSpectator() || !o.isAlive()) continue;
                Box bb = o.getBoundingBox().expand(0.3);
                var hit = bb.raycast(pos, next);
                if (hit.isPresent()) { r.hit = o; r.pts.add(hit.get()); return r; }
            }
            var bh = w.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (bh.getType() == HitResult.Type.BLOCK) { r.land = bh.getBlockPos(); r.pts.add(bh.getPos()); return r; }
            r.pts.add(next);
            pos = next; vel = vel.multiply(0.99).add(0, -grav, 0);
            if (pos.y < w.getBottomY() - 10) break;
        }
        return r;
    }
}
